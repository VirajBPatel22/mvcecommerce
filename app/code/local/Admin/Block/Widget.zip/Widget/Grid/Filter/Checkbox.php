<?php  
Class Admin_Block_Widget_Grid_Filter_Checkbox extends Core_Block_Template{
    
}

?>
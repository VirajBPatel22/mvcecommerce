<?php  
Class Admin_Block_Widget_Grid_Toolbar extends Core_Block_Template{
    
}

?>
<?php  
Class Admin_Block_Widget_Grid_Columns_Delete extends Core_Block_Template{
    
}

?>